'use strict';
var GrilledPrawn = (function () {
    
	var addFriendlist = [];
    var _openFilter = (page,elmnt,color) => {
    
	if (document.getElementById(page).style.display === 'none') {
        document.getElementById(page).style.display = 'block';
		elmnt.style.backgroundColor = color;
		elmnt.classList.add('active');
    } else {
        document.getElementById(page).style.display = 'none';
		elmnt.classList.remove('active');
    }
    };
	var  _scrollToTop = () =>{
	window.scrollTo(500,0);
	};   







var  _addFriend = ()=> {

	const firstName = document.getElementById('firstName').value;
	const surName = document.getElementById('surName').value;
	const email = document.getElementById('email').value;
	const userData = {
	firstName: firstName,
	surName: surName,
	email: email
	};
	addFriendlist.push(userData);

	for (var i = 0; i < addFriendlist.length; i++) {
	var addfriendData = '<ul>'+
						'<li><label class=\'invitefriend-section-friendlist-label\'>Name</label>' +
						'<input id=\'invitefriend-section-friendlist-name\' type=\'text\' value=\'' + addFriendlist[i].firstName + 
						'\' class=\'invitefriend-section-friendlist-input\'></li><li>' +
						'<label class=\'invitefriend-section-friendlist-label\'>Surname</label>'+
						'<input id=\'invitefriend-section-friendlist-surname\' type=\'text\' value=\'' + addFriendlist[i].surName +
						'\' class=\'invitefriend-section-friendlist-input\'></li><li>'+
						'<label class=\'invitefriend-section-friendlist-label\'>Email Address</label>' +
						'<input id=\'invitefriend-section-friendlist-email\' type=\'text\' value=\'' + addFriendlist[i].email + '\' class=\'invitefriend-section-friendlist-input\'></li><li>'+
						'<div><label class=\'invitefriend-section-friendlist-label\'><img src=\'image/dustbin.png\'>' +
						'<a href=\'javascript:void(0)\' onClick=\'GrilledPrawn.removeFriend(' + i + ');\'>Remove</a></label></div></li></ul>';
	//var addfriendData = "<div class='add-data'><form><ul><li><input type='text' id='fName' value=" + addFriendlist[i].firstName + "></li><li><input type='text' id='lName' value=" + addFriendlist[i].surName + "></li><li><input type='text' id='email1' value=" + addFriendlist[i].email + "> </li> <li><a href='javascript::void(0)' onClick='GrilledPrawn.removeFriend(" + i + ");'>Remove</a></li> </ul></form></div>"
	// var newFood = "<a href='#' onClick='removeRecord(" + i + ");'>X</a> " + foodList[i] + " <br>";
	}

	document.getElementById('invitefriend-section-friendlist').innerHTML += addfriendData;
	document.getElementById('firstName').value = '';
	document.getElementById('surName').value = '';
	document.getElementById('email').value = '';

};


var _removeFriend=(i)=> {
				addFriendlist.splice(i, 1);
				var removeFriendlist = '';
				for (var i = 0; i < addFriendlist.length; i++) {
				removeFriendlist += '<ul>'+
									'<li><label class=\'invitefriend-section-friendlist-label\'>Name</label>' +
									'<input id=\'invitefriend-section-friendlist-name\' type=\'text\' value=\'' + addFriendlist[i].firstName + 
									'\' class=\'invitefriend-section-friendlist-input\'></li><li>' +
									'<label class=\'invitefriend-section-friendlist-label\'>Surname</label>'+
									'<input id=\'invitefriend-section-friendlist-surname\' type=\'text\' value=\'' + addFriendlist[i].surName +
									'\' class=\'invitefriend-section-friendlist-input\'></li><li>'+
									'<label class=\'invitefriend-section-friendlist-label\'>Email Address</label>' +
									'<input id=\'invitefriend-section-friendlist-email\' type=\'text\' value=\'' + addFriendlist[i].email + '\' class=\'invitefriend-section-friendlist-input\'></li><li>'+
									'<div><label class=\'invitefriend-section-friendlist-label\'><img src=\'image/dustbin.png\'>' +
									'<a href=\'javascript:void(0)\' onClick=\'GrilledPrawn.removeFriend(' + i + ');\'>Remove</a></label></div></li></ul>';
				}
				document.getElementById('invitefriend-section-friendlist').innerHTML = removeFriendlist;

};
   
    return {
        openFilter:_openFilter,
		scrollToTop:_scrollToTop,
        addFriend:_addFriend,
        removeFriend:_removeFriend
    };
}());


